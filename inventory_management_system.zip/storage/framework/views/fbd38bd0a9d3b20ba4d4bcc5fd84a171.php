

<?php $__env->startSection('title', 'Expenses'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">Expenses</h1>
    <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-2"></i>Add Expense
    </a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Account</th>
                        <th>Description</th>
                        <th>Reference</th>
                        <th class="text-end">Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($expense->expense_date->format('d M, Y')); ?></td>
                        <td><?php echo e($expense->account->name); ?></td>
                        <td><?php echo e(Str::limit($expense->description, 50)); ?></td>
                        <td><?php echo e($expense->reference ?? '-'); ?></td>
                        <td class="text-end"><?php echo e(number_format($expense->amount, 2)); ?> TK</td>
                        <td>
                            <a href="<?php echo e(route('expenses.show', $expense)); ?>" class="btn btn-sm btn-outline-info">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4">No expenses found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($expenses->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\inventory_management_system\resources\views/expenses/index.blade.php ENDPATH**/ ?>