

<?php $__env->startSection('title', 'Product Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">Product Details</h1>
    <div>
        <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-primary me-2">
            <i class="bi bi-pencil me-2"></i>Edit
        </a>
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><?php echo e($product->name); ?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>SKU:</strong> <?php echo e($product->sku); ?></p>
                        <p><strong>Purchase Price:</strong> <?php echo e(number_format($product->purchase_price, 2)); ?> TK</p>
                        <p><strong>Sell Price:</strong> <?php echo e(number_format($product->sell_price, 2)); ?> TK</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Opening Stock:</strong> <?php echo e($product->opening_stock); ?></p>
                        <p><strong>Current Stock:</strong> <?php echo e($product->current_stock); ?></p>
                        <p><strong>Stock Value:</strong> <?php echo e(number_format($product->stock_value, 2)); ?> TK</p>
                    </div>
                </div>
                <?php if($product->description): ?>
                <hr>
                <p><strong>Description:</strong></p>
                <p><?php echo e($product->description); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Stock Summary</h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span>Profit Margin:</span>
                    <strong class="text-success"><?php echo e(number_format($product->sell_price - $product->purchase_price, 2)); ?> TK</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Margin %:</span>
                    <strong><?php echo e(number_format((($product->sell_price - $product->purchase_price) / $product->purchase_price) * 100, 1)); ?>%</strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span>Total Stock Value:</span>
                    <strong><?php echo e(number_format($product->stock_value, 2)); ?> TK</strong>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\inventory_management_system\resources\views/products/show.blade.php ENDPATH**/ ?>