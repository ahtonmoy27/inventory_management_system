

<?php $__env->startSection('title', 'Expense Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">Expense Details</h1>
    <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Back
    </a>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Expense Information</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Date:</strong> <?php echo e($expense->expense_date->format('d M, Y')); ?></p>
                        <p><strong>Account:</strong> <?php echo e($expense->account->code); ?> - <?php echo e($expense->account->name); ?></p>
                        <p><strong>Reference:</strong> <?php echo e($expense->reference ?? '-'); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Amount:</strong> <span class="fs-4 text-danger"><?php echo e(number_format($expense->amount, 2)); ?> TK</span></p>
                        <p><strong>Created:</strong> <?php echo e($expense->created_at->format('d M, Y H:i')); ?></p>
                    </div>
                </div>
                <hr>
                <p><strong>Description:</strong></p>
                <p><?php echo e($expense->description); ?></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\inventory_management_system\resources\views/expenses/show.blade.php ENDPATH**/ ?>