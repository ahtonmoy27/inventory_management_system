

<?php $__env->startSection('title', 'Account Balances'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">Chart of Accounts - Balances</h1>
</div>

<?php $__currentLoopData = $groupedAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><?php echo e(ucfirst($type)); ?> Accounts</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Account Name</th>
                        <th>Category</th>
                        <th class="text-end">Balance (TK)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($account->code); ?></td>
                        <td>
                            <?php echo e($account->name); ?>

                            <?php if($account->is_system): ?>
                                <span class="badge bg-secondary ms-2">System</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($account->category); ?></td>
                        <td class="text-end">
                            <?php if($account->balance >= 0): ?>
                                <span class="text-success"><?php echo e(number_format($account->balance, 2)); ?></span>
                            <?php else: ?>
                                <span class="text-danger">(<?php echo e(number_format(abs($account->balance), 2)); ?>)</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot class="table-light">
                    <tr>
                        <td colspan="3" class="text-end"><strong>Total <?php echo e(ucfirst($type)); ?>:</strong></td>
                        <td class="text-end">
                            <?php $total = $accounts->sum('balance'); ?>
                            <?php if($total >= 0): ?>
                                <strong class="text-success"><?php echo e(number_format($total, 2)); ?> TK</strong>
                            <?php else: ?>
                                <strong class="text-danger">(<?php echo e(number_format(abs($total), 2)); ?>) TK</strong>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">Accounting Equation Summary</h5>
    </div>
    <div class="card-body">
        <?php
            $assets = $groupedAccounts->get('asset', collect())->sum('balance');
            $liabilities = $groupedAccounts->get('liability', collect())->sum('balance');
            $equity = $groupedAccounts->get('equity', collect())->sum('balance');
            $revenue = $groupedAccounts->get('revenue', collect())->sum('balance');
            $expenses = $groupedAccounts->get('expense', collect())->sum('balance');
        ?>
        <div class="row text-center">
            <div class="col-md-4">
                <div class="p-3 bg-light rounded">
                    <h6 class="text-muted">Total Assets</h6>
                    <h3 class="text-success"><?php echo e(number_format($assets, 2)); ?> TK</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 bg-light rounded">
                    <h6 class="text-muted">Total Liabilities</h6>
                    <h3 class="text-danger"><?php echo e(number_format($liabilities, 2)); ?> TK</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 bg-light rounded">
                    <h6 class="text-muted">Owner's Equity</h6>
                    <h3 class="text-primary"><?php echo e(number_format($equity, 2)); ?> TK</h3>
                </div>
            </div>
        </div>
        <hr>
        <div class="row text-center">
            <div class="col-md-6">
                <div class="p-3 bg-light rounded">
                    <h6 class="text-muted">Total Revenue</h6>
                    <h3 class="text-success"><?php echo e(number_format($revenue, 2)); ?> TK</h3>
                </div>
            </div>
            <div class="col-md-6">
                <div class="p-3 bg-light rounded">
                    <h6 class="text-muted">Total Expenses</h6>
                    <h3 class="text-danger"><?php echo e(number_format($expenses, 2)); ?> TK</h3>
                </div>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <h5>Net Income: 
                <?php $netIncome = $revenue - $expenses; ?>
                <span class="<?php echo e($netIncome >= 0 ? 'text-success' : 'text-danger'); ?>">
                    <?php echo e(number_format($netIncome, 2)); ?> TK
                </span>
            </h5>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\inventory_management_system\resources\views/reports/account-balances.blade.php ENDPATH**/ ?>