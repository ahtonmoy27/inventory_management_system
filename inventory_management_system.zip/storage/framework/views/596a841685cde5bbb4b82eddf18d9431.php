

<?php $__env->startSection('title', 'Sales'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">Sales</h1>
    <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-2"></i>New Sale
    </a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Invoice</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Total</th>
                        <th>Paid</th>
                        <th>Due</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($sale->invoice_number); ?></td>
                        <td><?php echo e($sale->customer->name); ?></td>
                        <td><?php echo e($sale->sale_date->format('d M, Y')); ?></td>
                        <td><?php echo e(number_format($sale->total_amount, 2)); ?> TK</td>
                        <td><?php echo e(number_format($sale->paid_amount, 2)); ?> TK</td>
                        <td>
                            <?php if($sale->due_amount > 0): ?>
                                <span class="text-danger"><?php echo e(number_format($sale->due_amount, 2)); ?> TK</span>
                            <?php else: ?>
                                <span class="text-success">0.00 TK</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($sale->status == 'paid'): ?>
                                <span class="badge bg-success">Paid</span>
                            <?php elseif($sale->status == 'partial'): ?>
                                <span class="badge bg-warning">Partial</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('sales.show', $sale)); ?>" class="btn btn-sm btn-outline-info">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4">No sales found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($sales->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\inventory_management_system\resources\views/sales/index.blade.php ENDPATH**/ ?>