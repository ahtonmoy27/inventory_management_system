

<?php $__env->startSection('title', 'Sale Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">Sale Details</h1>
    <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Back
    </a>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Invoice: <?php echo e($sale->invoice_number); ?></h5>
                <?php if($sale->status == 'paid'): ?>
                    <span class="badge bg-success fs-6">Paid</span>
                <?php elseif($sale->status == 'partial'): ?>
                    <span class="badge bg-warning fs-6">Partial Payment</span>
                <?php else: ?>
                    <span class="badge bg-danger fs-6">Payment Pending</span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <p><strong>Customer:</strong> <?php echo e($sale->customer->name); ?></p>
                        <p><strong>Email:</strong> <?php echo e($sale->customer->email ?? '-'); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($sale->customer->phone ?? '-'); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Sale Date:</strong> <?php echo e($sale->sale_date->format('d M, Y')); ?></p>
                        <p><strong>Created:</strong> <?php echo e($sale->created_at->format('d M, Y H:i')); ?></p>
                    </div>
                </div>

                <h6>Items</h6>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Product</th>
                                <th>SKU</th>
                                <th class="text-center">Quantity</th>
                                <th class="text-end">Unit Price</th>
                                <th class="text-end">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->product->name); ?></td>
                                <td><?php echo e($item->product->sku); ?></td>
                                <td class="text-center"><?php echo e($item->quantity); ?></td>
                                <td class="text-end"><?php echo e(number_format($item->unit_price, 2)); ?> TK</td>
                                <td class="text-end"><?php echo e(number_format($item->total_price, 2)); ?> TK</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-end"><strong>Subtotal:</strong></td>
                                <td class="text-end"><?php echo e(number_format($sale->subtotal, 2)); ?> TK</td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-end"><strong>Discount:</strong></td>
                                <td class="text-end text-danger">-<?php echo e(number_format($sale->discount, 2)); ?> TK</td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-end"><strong>VAT (<?php echo e($sale->vat_percentage); ?>%):</strong></td>
                                <td class="text-end"><?php echo e(number_format($sale->vat_amount, 2)); ?> TK</td>
                            </tr>
                            <tr class="table-primary">
                                <td colspan="4" class="text-end"><strong>Total Amount:</strong></td>
                                <td class="text-end fw-bold"><?php echo e(number_format($sale->total_amount, 2)); ?> TK</td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-end"><strong>Paid Amount:</strong></td>
                                <td class="text-end text-success"><?php echo e(number_format($sale->paid_amount, 2)); ?> TK</td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-end"><strong>Due Amount:</strong></td>
                                <td class="text-end text-danger fw-bold"><?php echo e(number_format($sale->due_amount, 2)); ?> TK</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <?php if($sale->journalEntry): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Journal Entry: <?php echo e($sale->journalEntry->entry_number); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Account</th>
                                <th>Description</th>
                                <th class="text-end">Debit (TK)</th>
                                <th class="text-end">Credit (TK)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sale->journalEntry->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($line->account->code); ?> - <?php echo e($line->account->name); ?></td>
                                <td><?php echo e($line->description); ?></td>
                                <td class="text-end"><?php echo e($line->debit > 0 ? number_format($line->debit, 2) : '-'); ?></td>
                                <td class="text-end"><?php echo e($line->credit > 0 ? number_format($line->credit, 2) : '-'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="2" class="text-end"><strong>Total:</strong></td>
                                <td class="text-end"><strong><?php echo e(number_format($sale->journalEntry->total_debit, 2)); ?></strong></td>
                                <td class="text-end"><strong><?php echo e(number_format($sale->journalEntry->total_credit, 2)); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Payment Summary</h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span>Subtotal:</span>
                    <strong><?php echo e(number_format($sale->subtotal, 2)); ?> TK</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Discount:</span>
                    <strong class="text-danger">-<?php echo e(number_format($sale->discount, 2)); ?> TK</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>VAT (<?php echo e($sale->vat_percentage); ?>%):</span>
                    <strong><?php echo e(number_format($sale->vat_amount, 2)); ?> TK</strong>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-2">
                    <span class="fs-5">Total:</span>
                    <strong class="fs-5"><?php echo e(number_format($sale->total_amount, 2)); ?> TK</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Paid:</span>
                    <strong class="text-success"><?php echo e(number_format($sale->paid_amount, 2)); ?> TK</strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span>Due:</span>
                    <strong class="text-danger"><?php echo e(number_format($sale->due_amount, 2)); ?> TK</strong>
                </div>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0">Cost Analysis</h5>
            </div>
            <div class="card-body">
                <?php
                    $cogs = 0;
                    foreach($sale->items as $item) {
                        $cogs += $item->quantity * $item->product->purchase_price;
                    }
                    $grossProfit = $sale->subtotal - $sale->discount - $cogs;
                ?>
                <div class="d-flex justify-content-between mb-2">
                    <span>Cost of Goods:</span>
                    <strong><?php echo e(number_format($cogs, 2)); ?> TK</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Gross Profit:</span>
                    <strong class="<?php echo e($grossProfit >= 0 ? 'text-success' : 'text-danger'); ?>">
                        <?php echo e(number_format($grossProfit, 2)); ?> TK
                    </strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span>Profit Margin:</span>
                    <strong>
                        <?php if($sale->subtotal > 0): ?>
                            <?php echo e(number_format(($grossProfit / $sale->subtotal) * 100, 1)); ?>%
                        <?php else: ?>
                            0%
                        <?php endif; ?>
                    </strong>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\inventory_management_system\resources\views/sales/show.blade.php ENDPATH**/ ?>